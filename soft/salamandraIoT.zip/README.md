# IoT SaaS Admin - Fase 1

Frontend administrador en **HTML + CSS + JavaScript** listo para publicar en **GitHub Pages** y conectar con **Supabase**.

## Incluye
- Login
- Registro
- Recuperar contraseña
- Dashboard admin
- Clientes
- Usuarios
- Devices
- Roles y permisos
- Broker
- Suscripciones
- Planes
- Perfil
- Notificaciones
- Tema claro/oscuro
- PWA base
- SweetAlert2
- Router hash para github.io

## Publicación en GitHub Pages
1. Subí estos archivos a un repositorio.
2. En **Settings > Pages**, elegí la rama principal y la carpeta raíz.
3. Editá `assets/js/config.js` con tu proyecto Supabase.
4. Listo.

## Configuración Supabase
Reemplazá en `assets/js/config.js`:
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`

## Auth esperado
Este frontend usa:
- `supabase.auth.signInWithPassword`
- `supabase.auth.signUp`
- `supabase.auth.resetPasswordForEmail`
- `supabase.auth.getSession`

## Notas
- La seguridad real debe quedar en Supabase RLS.
- El router usa `#/ruta` para evitar problemas en github.io.
- Los datos del dashboard y ABM están mockeados en `data/mocks.js` para Fase 1.
