import { initTheme, toggleTheme } from "./theme.js";
import { getSession, signOut } from "./auth.js";
import { registerServiceWorker } from "./pwa.js";
import { renderRoute, navigate } from "./router.js";
import { qs } from "./utils.js";
import { confirmAction } from "./alerts.js";

const app = document.getElementById("app");

async function bootstrap() {
  initTheme();
  registerServiceWorker();
  try {
    await getSession();
  } catch (err) {
    console.error(err);
  }
  await renderRoute(app);
}

window.addEventListener("hashchange", () => renderRoute(app));
window.addEventListener("DOMContentLoaded", bootstrap);

document.addEventListener("click", async (event) => {
  const themeBtn = event.target.closest("[data-action='toggle-theme']");
  if (themeBtn) toggleTheme();

  const navBtn = event.target.closest("[data-nav]");
  if (navBtn) navigate(navBtn.dataset.nav);

  const logoutBtn = event.target.closest("[data-action='logout']");
  if (logoutBtn) {
    const ok = await confirmAction("¿Querés cerrar sesión?");
    if (ok.isConfirmed) {
      await signOut();
      navigate("/login");
    }
  }
});

document.addEventListener("view:rendered", () => {
  const route = location.hash.replace(/^#/, "") || "/login";
  qsAll(".sidebar-link").forEach((el) => {
    el.classList.toggle("active", el.getAttribute("href") === `#${route}`);
  });
});

function qsAll(selector) {
  return Array.from(document.querySelectorAll(selector));
}
