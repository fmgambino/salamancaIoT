export const APP_CONFIG = {
  APP_NAME: "IoT SaaS Admin",
  SUPABASE_URL: "https://mgzqtvabzsjfygzsaxlq.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_8oJHVuGNXKw07jxXzK_fNA_AUAlGHxk",
  DEFAULT_THEME: "light",
  ROUTE_PREFIX: "#"
};
