import { isAuthenticated } from "./auth.js";
import { can } from "./permissions.js";
import { isSubscriptionBlocked } from "./subscriptions.js";

const publicRoutes = new Set(["/login", "/register", "/forgot-password"]);

export function requireAuth(route) {
  if (publicRoutes.has(route)) return true;
  return isAuthenticated();
}

export function requirePermission(moduleKey, action = "ver") {
  return can(moduleKey, action);
}

export function requireSubscription() {
  return !isSubscriptionBlocked();
}
