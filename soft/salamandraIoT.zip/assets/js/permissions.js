import { state } from "./state.js";

export function can(moduleKey, action) {
  const actions = state.permissions[moduleKey] || [];
  return actions.includes(action);
}
