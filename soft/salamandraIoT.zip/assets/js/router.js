import { renderLoginView } from "../../views/login.js";
import { renderRegisterView } from "../../views/register.js";
import { renderForgotPasswordView } from "../../views/forgot-password.js";
import { renderDashboardView } from "../../views/dashboard.js";
import { renderClientsView } from "../../views/clients.js";
import { renderUsersView } from "../../views/users.js";
import { renderDevicesView } from "../../views/devices.js";
import { renderRolesView } from "../../views/roles.js";
import { renderBrokerView } from "../../views/broker.js";
import { renderSubscriptionsView } from "../../views/subscriptions.js";
import { renderPlansView } from "../../views/plans.js";
import { renderProfileView } from "../../views/profile.js";
import { renderNotificationsView } from "../../views/notifications.js";
import { renderUnauthorizedView } from "../../views/unauthorized.js";
import { renderNotFoundView } from "../../views/not-found.js";
import { requireAuth, requirePermission } from "./guards.js";

const routes = {
  "/login": { render: renderLoginView, public: true },
  "/register": { render: renderRegisterView, public: true },
  "/forgot-password": { render: renderForgotPasswordView, public: true },

  "/admin/dashboard": { render: renderDashboardView, module: "dashboard_admin" },
  "/admin/clientes": { render: renderClientsView, module: "clientes" },
  "/admin/usuarios": { render: renderUsersView, module: "usuarios" },
  "/admin/devices": { render: renderDevicesView, module: "devices" },
  "/admin/roles": { render: renderRolesView, module: "roles" },
  "/admin/broker": { render: renderBrokerView, module: "broker" },
  "/admin/suscripciones": { render: renderSubscriptionsView, module: "suscripciones" },
  "/admin/planes": { render: renderPlansView, module: "planes" },
  "/admin/perfil": { render: renderProfileView, module: "perfil" },
  "/admin/notificaciones": { render: renderNotificationsView, module: "notificaciones" },

  "/unauthorized": { render: renderUnauthorizedView, public: true }
};

export function getCurrentRoute() {
  const hash = location.hash.replace(/^#/, "");
  return hash || "/login";
}

export function navigate(path) {
  location.hash = path;
}

export async function renderRoute(appRoot) {
  const current = getCurrentRoute();
  const route = routes[current];

  if (!route) {
    appRoot.innerHTML = renderNotFoundView();
    return;
  }

  if (!requireAuth(current)) {
    navigate("/login");
    return;
  }

  if (!route.public && route.module && !requirePermission(route.module, "ver")) {
    appRoot.innerHTML = renderUnauthorizedView();
    return;
  }

  const html = await route.render();
  appRoot.innerHTML = html;
  document.dispatchEvent(new CustomEvent("view:rendered", { detail: { route: current } }));
}
