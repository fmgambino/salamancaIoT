export const state = {
  session: null,
  profile: null,
  theme: "light",
  permissions: {
    dashboard_admin: ["ver"],
    usuarios: ["ver", "crear", "editar", "eliminar"],
    clientes: ["ver", "crear", "editar", "eliminar"],
    devices: ["ver", "crear", "editar", "eliminar"],
    roles: ["ver", "administrar"],
    broker: ["ver", "editar"],
    suscripciones: ["ver", "administrar"],
    planes: ["ver", "editar"],
    notificaciones: ["ver"],
    perfil: ["ver", "editar"]
  },
  subscription: {
    status: "active",
    plan: "Business",
    period: "monthly",
    devicesUsed: 3,
    devicesLimit: null,
    expiresAt: "2026-12-31"
  }
};
