import { state } from "./state.js";
import { warning } from "./alerts.js";

export function getSubscription() {
  return state.subscription;
}

export function isSubscriptionBlocked() {
  return ["expired", "suspended", "canceled", "pending_payment"].includes(state.subscription.status);
}

export async function showSubscriptionBlockAlert() {
  return warning("La suscripción está bloqueada. Renová o cambiá el plan para continuar.");
}
