import { APP_CONFIG } from "./config.js";
import { state } from "./state.js";

const KEY = "iot-admin-theme";

export function initTheme() {
  const saved = localStorage.getItem(KEY) || APP_CONFIG.DEFAULT_THEME;
  setTheme(saved);
}

export function setTheme(theme) {
  state.theme = theme;
  document.documentElement.setAttribute("data-theme", theme);
  localStorage.setItem(KEY, theme);
}

export function toggleTheme() {
  setTheme(state.theme === "light" ? "dark" : "light");
}
