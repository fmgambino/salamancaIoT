export function statusBadge(status) {
  const map = {
    active: "success",
    online: "success",
    expired: "danger",
    offline: "warning",
    suspended: "warning",
    pending_payment: "warning",
    business: "info"
  };
  const klass = map[String(status).toLowerCase()] || "info";
  return `<span class="badge ${klass}">${status}</span>`;
}
