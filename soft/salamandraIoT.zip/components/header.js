import { state } from "../assets/js/state.js";

export function renderHeader(title = "Panel administrador") {
  return `
    <header class="topbar">
      <div class="topbar-left">
        <div>
          <div class="breadcrumbs">Inicio / ${title}</div>
          <strong>${title}</strong>
        </div>
      </div>

      <div class="topbar-right">
        <button class="btn icon-btn" data-action="toggle-theme" title="Cambiar tema">◐</button>
        <button class="btn" data-nav="/admin/notificaciones">🔔</button>
        <div class="avatar">${(state.session?.user?.email || "A").slice(0,1).toUpperCase()}</div>
        <button class="btn" data-action="logout">Salir</button>
      </div>
    </header>
  `;
}
