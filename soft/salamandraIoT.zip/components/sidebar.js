export function renderSidebar() {
  const items = [
    ["/admin/dashboard", "Dashboard"],
    ["/admin/clientes", "Clientes"],
    ["/admin/usuarios", "Usuarios"],
    ["/admin/devices", "Devices"],
    ["/admin/roles", "Roles y permisos"],
    ["/admin/broker", "Broker"],
    ["/admin/suscripciones", "Suscripciones"],
    ["/admin/planes", "Planes"],
    ["/admin/perfil", "Mi perfil"],
    ["/admin/notificaciones", "Notificaciones"]
  ];

  return `
    <aside class="sidebar">
      <div class="sidebar-brand">
        <div class="sidebar-brand-mark">I</div>
        <div>
          <strong>IoT SaaS Admin</strong>
          <div class="muted">Fase 1</div>
        </div>
      </div>

      <nav class="sidebar-nav">
        ${items.map(([path, label]) => `
          <a class="sidebar-link" href="#${path}">${label}</a>
        `).join("")}
      </nav>
    </aside>
  `;
}
