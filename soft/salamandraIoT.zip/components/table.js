export function renderTable({ title, columns, rows, actions = [], toolbar = "" }) {
  const head = columns.map(c => `<th>${c.label}</th>`).join("");
  const body = rows.map(row => `
    <tr>
      ${columns.map(c => `<td>${typeof c.render === "function" ? c.render(row) : (row[c.key] ?? "-")}</td>`).join("")}
      <td>
        <div class="table-actions">
          ${actions.map(a => `<button class="btn" data-row-id="${row.id}" data-table-action="${a.key}">${a.label}</button>`).join("")}
        </div>
      </td>
    </tr>
  `).join("");

  return `
    <section class="table-card">
      <div class="table-toolbar">
        <div class="page-header">
          <div>
            <h2 style="margin:0">${title}</h2>
          </div>
          <div class="toolbar">${toolbar}</div>
        </div>
      </div>
      <div class="table-wrap">
        <table class="app-table">
          <thead>
            <tr>${head}<th>Acciones</th></tr>
          </thead>
          <tbody>${body}</tbody>
        </table>
      </div>
      <div class="table-footer">
        <span class="muted">Mostrando ${rows.length} registros</span>
        <div class="toolbar">
          <button class="btn">Anterior</button>
          <button class="btn">Siguiente</button>
        </div>
      </div>
    </section>
  `;
}
