export const dashboardStats = [
  { label: "Clientes", value: 128 },
  { label: "Usuarios", value: 412 },
  { label: "Devices", value: 987 },
  { label: "Online", value: 642 },
  { label: "Offline", value: 345 },
  { label: "Vencidas", value: 19 }
];

export const clients = [
  { id: 1, name: "Agro Norte", plan: "PyME", subscription: "active", devices: "3/5", mainPlace: "Planta 1", expiresAt: "2026-06-30" },
  { id: 2, name: "Frío Sur", plan: "Emprender", subscription: "expired", devices: "1/1", mainPlace: "Depósito", expiresAt: "2026-03-10" },
  { id: 3, name: "Metalúrgica Río", plan: "Business", subscription: "active", devices: "18/∞", mainPlace: "Nave A", expiresAt: "2026-11-15" }
];

export const users = [
  { id: 1, name: "Ana López", email: "ana@demo.com", role: "Admin", client: "-", status: "active", lastLogin: "2026-04-10" },
  { id: 2, name: "Pablo Ruiz", email: "pablo@agro.com", role: "Operador", client: "Agro Norte", status: "active", lastLogin: "2026-04-11" }
];

export const devices = [
  { id: 1, name: "ESP32-001", deviceId: "dev-001", client: "Agro Norte", place: "Planta 1", type: "ESP32", status: "online", plan: "PyME", lastSeen: "2026-04-13" },
  { id: 2, name: "ESP32-002", deviceId: "dev-002", client: "Frío Sur", place: "Depósito", type: "ESP32", status: "offline", plan: "Emprender", lastSeen: "2026-04-12" }
];

export const subscriptions = [
  { id: 1, client: "Agro Norte", plan: "PyME", mode: "monthly", status: "active", startDate: "2026-04-01", endDate: "2026-04-30", devices: "3/5" },
  { id: 2, client: "Frío Sur", plan: "Emprender", mode: "yearly", status: "expired", startDate: "2025-03-10", endDate: "2026-03-10", devices: "1/1" }
];

export const notifications = [
  { id: 1, type: "suscripción", message: "Frío Sur tiene la suscripción vencida.", date: "2026-04-13" },
  { id: 2, type: "device", message: "ESP32-002 quedó offline.", date: "2026-04-13" }
];

export const plans = [
  { id: 1, name: "Emprender", monthly: "USD 2.99", yearly: "USD 29.99", limit: "1 dispositivo" },
  { id: 2, name: "PyME", monthly: "USD 14.99", yearly: "USD 129.99", limit: "5 dispositivos" },
  { id: 3, name: "Business", monthly: "USD 99.99", yearly: "USD 999.99", limit: "Ilimitado" }
];
