import { renderAdminLayout } from "./layout.js";
import { success } from "../assets/js/alerts.js";

export async function renderBrokerView() {
  setTimeout(bindBrokerEvents, 0);
  const content = `
    <div class="content-stack">
      <div class="page-header">
        <div>
          <h1 class="page-title">Broker MQTT</h1>
          <p class="page-subtitle">Configuración base del broker y topics raíz.</p>
        </div>
      </div>

      <div class="grid grid-2">
        <section class="panel">
          <form id="broker-form" class="form-grid">
            <div class="form-row"><label>Host</label><input class="input" name="host" value="broker.emqx.io" /></div>
            <div class="form-row"><label>Puerto TCP</label><input class="input" name="tcp" value="1883" /></div>
            <div class="form-row"><label>Puerto WebSocket</label><input class="input" name="ws" value="8083" /></div>
            <div class="form-row"><label>Puerto TLS</label><input class="input" name="tls" value="8883" /></div>
            <div class="form-row"><label>Puerto WSS</label><input class="input" name="wss" value="8084" /></div>
            <div class="form-row"><label>Topic raíz</label><input class="input" name="base" value="app/devices" /></div>
            <div class="toolbar">
              <button class="btn" type="button" id="test-broker-btn">Probar</button>
              <button class="btn btn-primary" type="submit">Guardar</button>
            </div>
          </form>
        </section>

        <section class="panel">
          <h2>Convención sugerida</h2>
          <ul class="list-clean">
            <li><code>app/devices/{device_id}/telemetry</code></li>
            <li><code>app/devices/{device_id}/status</code></li>
            <li><code>app/devices/{device_id}/command</code></li>
            <li><code>app/devices/{device_id}/response</code></li>
            <li><code>app/devices/{device_id}/heartbeat</code></li>
          </ul>
        </section>
      </div>
    </div>
  `;
  return renderAdminLayout("Broker", content);
}

function bindBrokerEvents() {
  document.getElementById("test-broker-btn")?.addEventListener("click", async () => {
    await success("Configuración validada visualmente. La prueba real queda para Fase 3.");
  });

  document.getElementById("broker-form")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    await success("Configuración guardada.");
  });
}
