import { renderAdminLayout } from "./layout.js";
import { clients } from "../data/mocks.js";
import { renderTable } from "../components/table.js";
import { statusBadge } from "../components/badges.js";
import { success } from "../assets/js/alerts.js";

export async function renderClientsView() {
  setTimeout(bindClientActions, 0);

  const content = `
    <div class="content-stack">
      <div class="page-header">
        <div>
          <h1 class="page-title">Clientes + dispositivos</h1>
          <p class="page-subtitle">Visualización general de clientes, plan, estado y consumo de cupo.</p>
        </div>
        <div class="toolbar">
          <button class="btn btn-primary" id="new-client-btn">Nuevo cliente</button>
        </div>
      </div>

      ${renderTable({
        title: "Listado de clientes",
        columns: [
          { key: "name", label: "Cliente" },
          { key: "plan", label: "Plan" },
          { key: "subscription", label: "Estado", render: row => statusBadge(row.subscription) },
          { key: "devices", label: "Devices usados" },
          { key: "mainPlace", label: "Lugar principal" },
          { key: "expiresAt", label: "Vencimiento" }
        ],
        rows: clients,
        actions: [
          { key: "view", label: "Ver" },
          { key: "edit", label: "Editar" },
          { key: "devices", label: "Devices" }
        ],
        toolbar: `
          <input class="input search-input" placeholder="Buscar cliente..." />
          <button class="btn">Filtrar</button>
          <button class="btn">Refrescar</button>
        `
      })}
    </div>
  `;

  return renderAdminLayout("Clientes", content);
}

function bindClientActions() {
  document.getElementById("new-client-btn")?.addEventListener("click", async () => {
    await success("Acá podés abrir el modal de alta de cliente.");
  });
}
