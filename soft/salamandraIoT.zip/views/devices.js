import { renderAdminLayout } from "./layout.js";
import { devices } from "../data/mocks.js";
import { renderTable } from "../components/table.js";
import { statusBadge } from "../components/badges.js";
import { success, warning } from "../assets/js/alerts.js";

export async function renderDevicesView() {
  setTimeout(bindDeviceActions, 0);

  const content = `
    <div class="content-stack">
      <div class="page-header">
        <div>
          <h1 class="page-title">Devices</h1>
          <p class="page-subtitle">ABM de dispositivos y asociación con clientes y lugares.</p>
        </div>
        <button class="btn btn-primary" id="new-device-btn">Nuevo device</button>
      </div>

      ${renderTable({
        title: "Listado de devices",
        columns: [
          { key: "name", label: "Nombre" },
          { key: "deviceId", label: "Device ID" },
          { key: "client", label: "Cliente" },
          { key: "place", label: "Lugar" },
          { key: "type", label: "Tipo" },
          { key: "status", label: "Estado", render: row => statusBadge(row.status) },
          { key: "plan", label: "Plan" },
          { key: "lastSeen", label: "Última conexión" }
        ],
        rows: devices,
        actions: [
          { key: "view", label: "Ver" },
          { key: "edit", label: "Editar" },
          { key: "delete", label: "Eliminar" }
        ],
        toolbar: `
          <input class="input search-input" placeholder="Buscar device..." />
          <button class="btn">Filtrar</button>
          <button class="btn">Refrescar</button>
        `
      })}
    </div>
  `;
  return renderAdminLayout("Devices", content);
}

function bindDeviceActions() {
  document.getElementById("new-device-btn")?.addEventListener("click", async () => {
    await warning("En Fase 2 acá debés validar el límite de devices por plan antes de guardar.");
  });
}
