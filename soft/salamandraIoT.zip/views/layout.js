import { renderSidebar } from "../components/sidebar.js";
import { renderHeader } from "../components/header.js";

export function renderAdminLayout(title, content) {
  return `
    <div class="app-shell">
      ${renderSidebar()}
      <div class="main-shell">
        ${renderHeader(title)}
        <main class="app-content">
          ${content}
        </main>
      </div>
    </div>
  `;
}
