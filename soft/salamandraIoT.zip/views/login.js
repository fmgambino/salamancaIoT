import { signIn } from "../assets/js/auth.js";
import { success, error } from "../assets/js/alerts.js";

export async function renderLoginView() {
  setTimeout(bindLoginEvents, 0);
  return `
    <section class="auth-shell">
      <div class="auth-card">
        <div class="logo-inline"><strong>IoT SaaS Admin</strong></div>
        <h1 class="auth-title">Iniciar sesión</h1>
        <p class="auth-subtitle">Accedé al panel administrador con Supabase Auth.</p>

        <form id="login-form" class="form-grid">
          <div class="form-row">
            <label>Email</label>
            <input class="input" type="email" name="email" required placeholder="admin@demo.com" />
          </div>
          <div class="form-row">
            <label>Contraseña</label>
            <input class="input" type="password" name="password" required placeholder="••••••••" />
          </div>
          <button class="btn btn-primary" type="submit">Ingresar</button>
        </form>

        <div class="auth-links">
          <a href="#/forgot-password">Olvidé mi contraseña</a>
          <a href="#/register">Crear cuenta</a>
        </div>
      </div>
    </section>
  `;
}

function bindLoginEvents() {
  const form = document.getElementById("login-form");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const data = new FormData(form);
    try {
      await signIn(data.get("email"), data.get("password"));
      await success("Sesión iniciada correctamente.");
      location.hash = "/admin/dashboard";
    } catch (err) {
      error(err.message || "No se pudo iniciar sesión.");
    }
  });
}
