import { renderAdminLayout } from "./layout.js";
import { notifications } from "../data/mocks.js";

export async function renderNotificationsView() {
  const content = `
    <div class="content-stack">
      <div class="page-header">
        <div>
          <h1 class="page-title">Notificaciones</h1>
          <p class="page-subtitle">Listado de alertas y eventos del sistema.</p>
        </div>
        <div class="toolbar">
          <button class="btn">Marcar todas leídas</button>
        </div>
      </div>

      <section class="panel">
        <ul class="list-clean">
          ${notifications.map(n => `
            <li class="notification-item">
              <strong>${n.type}</strong>
              <p style="margin:6px 0">${n.message}</p>
              <span class="muted">${n.date}</span>
            </li>
          `).join("")}
        </ul>
      </section>
    </div>
  `;
  return renderAdminLayout("Notificaciones", content);
}
