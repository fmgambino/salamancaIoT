import { renderAdminLayout } from "./layout.js";
import { plans } from "../data/mocks.js";

export async function renderPlansView() {
  const content = `
    <div class="content-stack">
      <div class="page-header">
        <div>
          <h1 class="page-title">Planes</h1>
          <p class="page-subtitle">Gestión de planes SaaS y límite de dispositivos.</p>
        </div>
      </div>

      <div class="grid grid-3">
        ${plans.map(plan => `
          <article class="card">
            <h2>${plan.name}</h2>
            <p><strong>Mensual:</strong> ${plan.monthly}</p>
            <p><strong>Anual:</strong> ${plan.yearly}</p>
            <p><strong>Límite:</strong> ${plan.limit}</p>
            <div class="toolbar">
              <button class="btn">Editar</button>
              <button class="btn btn-primary">Activar</button>
            </div>
          </article>
        `).join("")}
      </div>
    </div>
  `;
  return renderAdminLayout("Planes", content);
}
