import { renderAdminLayout } from "./layout.js";

export async function renderProfileView() {
  const content = `
    <div class="content-stack">
      <div class="page-header">
        <div>
          <h1 class="page-title">Mi perfil</h1>
          <p class="page-subtitle">Datos personales, seguridad y preferencias.</p>
        </div>
      </div>

      <div class="grid grid-2">
        <section class="panel">
          <h2>Datos personales</h2>
          <form class="form-grid">
            <div class="form-row"><label>Nombre</label><input class="input" value="Administrador" /></div>
            <div class="form-row"><label>Email</label><input class="input" value="admin@demo.com" /></div>
            <div class="form-row"><label>Rol</label><input class="input" value="Admin" disabled /></div>
            <button class="btn btn-primary" type="button">Guardar cambios</button>
          </form>
        </section>

        <section class="panel">
          <h2>Preferencias</h2>
          <div class="form-grid">
            <label class="switch"><input type="checkbox" checked /> Tema oscuro</label>
            <label class="switch"><input type="checkbox" /> Notificaciones email</label>
            <label class="switch"><input type="checkbox" checked /> Alertas críticas</label>
          </div>
        </section>
      </div>
    </div>
  `;
  return renderAdminLayout("Mi perfil", content);
}
