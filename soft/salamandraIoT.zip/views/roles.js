import { renderAdminLayout } from "./layout.js";

export async function renderRolesView() {
  const matrixRows = [
    ["dashboard_admin", "✔", "-", "-", "-", "-"],
    ["usuarios", "✔", "✔", "✔", "✔", "-"],
    ["clientes", "✔", "✔", "✔", "✔", "-"],
    ["devices", "✔", "✔", "✔", "✔", "-"],
    ["suscripciones", "✔", "-", "-", "-", "✔"]
  ];

  const content = `
    <div class="content-stack">
      <div class="page-header">
        <div>
          <h1 class="page-title">Roles y permisos</h1>
          <p class="page-subtitle">Matriz inicial de permisos por módulo y acción.</p>
        </div>
        <div class="toolbar">
          <button class="btn">Nuevo rol</button>
          <button class="btn btn-primary">Guardar cambios</button>
        </div>
      </div>

      <section class="table-card">
        <div class="table-wrap">
          <table class="app-table">
            <thead>
              <tr>
                <th>Módulo</th>
                <th>Ver</th>
                <th>Crear</th>
                <th>Editar</th>
                <th>Eliminar</th>
                <th>Administrar</th>
              </tr>
            </thead>
            <tbody>
              ${matrixRows.map(r => `
                <tr>
                  <td>${r[0]}</td>
                  <td>${r[1]}</td>
                  <td>${r[2]}</td>
                  <td>${r[3]}</td>
                  <td>${r[4]}</td>
                  <td>${r[5]}</td>
                </tr>
              `).join("")}
            </tbody>
          </table>
        </div>
      </section>
    </div>
  `;
  return renderAdminLayout("Roles y permisos", content);
}
