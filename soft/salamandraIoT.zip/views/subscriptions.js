import { renderAdminLayout } from "./layout.js";
import { subscriptions } from "../data/mocks.js";
import { renderTable } from "../components/table.js";
import { statusBadge } from "../components/badges.js";

export async function renderSubscriptionsView() {
  const content = `
    <div class="content-stack">
      <div class="page-header">
        <div>
          <h1 class="page-title">Suscripciones</h1>
          <p class="page-subtitle">Control de planes, estado, vencimiento y cupo de devices.</p>
        </div>
      </div>

      ${renderTable({
        title: "Listado de suscripciones",
        columns: [
          { key: "client", label: "Cliente" },
          { key: "plan", label: "Plan" },
          { key: "mode", label: "Modalidad" },
          { key: "status", label: "Estado", render: row => statusBadge(row.status) },
          { key: "startDate", label: "Inicio" },
          { key: "endDate", label: "Vencimiento" },
          { key: "devices", label: "Devices usados" }
        ],
        rows: subscriptions,
        actions: [
          { key: "renew", label: "Renovar" },
          { key: "change", label: "Cambiar plan" }
        ],
        toolbar: `
          <button class="btn">Activas</button>
          <button class="btn">Vencidas</button>
          <button class="btn">Próximas a vencer</button>
        `
      })}
    </div>
  `;
  return renderAdminLayout("Suscripciones", content);
}
