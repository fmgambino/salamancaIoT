import { renderAdminLayout } from "./layout.js";
import { users } from "../data/mocks.js";
import { renderTable } from "../components/table.js";
import { statusBadge } from "../components/badges.js";
import { success } from "../assets/js/alerts.js";

export async function renderUsersView() {
  setTimeout(bindUserActions, 0);

  const content = `
    <div class="content-stack">
      <div class="page-header">
        <div>
          <h1 class="page-title">Usuarios</h1>
          <p class="page-subtitle">ABM de usuarios, roles y cliente asociado.</p>
        </div>
        <button class="btn btn-primary" id="new-user-btn">Nuevo usuario</button>
      </div>

      ${renderTable({
        title: "Listado de usuarios",
        columns: [
          { key: "name", label: "Nombre" },
          { key: "email", label: "Email" },
          { key: "role", label: "Rol" },
          { key: "client", label: "Cliente" },
          { key: "status", label: "Estado", render: row => statusBadge(row.status) },
          { key: "lastLogin", label: "Último acceso" }
        ],
        rows: users,
        actions: [
          { key: "edit", label: "Editar" },
          { key: "toggle", label: "Activar/Desactivar" },
          { key: "delete", label: "Eliminar" }
        ],
        toolbar: `
          <input class="input search-input" placeholder="Buscar usuario..." />
          <button class="btn">Filtrar</button>
          <button class="btn">Refrescar</button>
        `
      })}
    </div>
  `;
  return renderAdminLayout("Usuarios", content);
}

function bindUserActions() {
  document.getElementById("new-user-btn")?.addEventListener("click", async () => {
    await success("Acá podés abrir el modal de alta de usuario.");
  });
}
