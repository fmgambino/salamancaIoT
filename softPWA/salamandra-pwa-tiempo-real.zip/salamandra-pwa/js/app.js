/* Salamandra IoT PWA - GitHub Pages ready - SVG minimal icons */
const SUPABASE_URL = 'https://REEMPLAZAR.supabase.co';
const SUPABASE_ANON_KEY = 'REEMPLAZAR_ANON_KEY';
const db = window.supabase?.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
const $ = s => document.querySelector(s), $$ = s => [...document.querySelectorAll(s)];
const defaultCfg={logoLight:'https://i.ibb.co/fzt4pJhL/logo-Salamandra-Ligth.png',logoDark:'https://i.ibb.co/1f0VBNpF/logo-Salamandra-Dark01.png',favicon:'https://i.ibb.co/67mjNJ3R/icon-Circulo-Salamandra-dark.png',installIcon:'https://i.ibb.co/67pSLYmV/icon-Circulo-Salamandra-ligth.png'};
let state=JSON.parse(localStorage.salamandra||'{}');
state={theme:'dark',role:'superadmin',user:null,places:['Casa','Edificio'],selectedPlace:'Casa',selectedDevice:'ESP12345',settings:defaultCfg,sensors:[],devices:[],actuators:[],plans:[],...state};
const save=()=>localStorage.salamandra=JSON.stringify(state);
const toast=(t,icon='success')=>Swal.fire({toast:true,position:'top-end',timer:2200,showConfirmButton:false,icon,title:t});
const confirmAction=({title='Confirmar acción',text='¿Deseás continuar?',icon='question',confirmButtonText='Confirmar',cancelButtonText='Cancelar'}={})=>Swal.fire({title,text,icon,showCancelButton:true,confirmButtonText,cancelButtonText,reverseButtons:true,focusCancel:true,confirmButtonColor:'#00b894',cancelButtonColor:'#64748b'}).then(r=>r.isConfirmed);
const safeHtml=s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const svg=(name,cls='svg-icon')=>{const common=`class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"`;const paths={
 dashboard:'<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
 users:'<path d="M16 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"/><circle cx="9.5" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
 shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-5"/>',
 plans:'<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M3 10h18"/><path d="M7 15h4"/>',
 plug:'<path d="M12 22v-5"/><path d="M9 8V2"/><path d="M15 8V2"/><path d="M7 8h10v4a5 5 0 0 1-10 0V8Z"/>',
 user:'<circle cx="12" cy="8" r="4"/><path d="M4 22a8 8 0 0 1 16 0"/>',
 cloud:'<path d="M17.5 19H7a5 5 0 1 1 1-9.9A7 7 0 0 1 21 12.5 3.5 3.5 0 0 1 17.5 19Z"/>',
 settings:'<path d="M12 15.5A3.5 3.5 0 1 0 12 8a3.5 3.5 0 0 0 0 7.5Z"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.88l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6V20a2 2 0 1 1-4 0v-.09a1.7 1.7 0 0 0-1-.51 1.7 1.7 0 0 0-1.88.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-.6-1H4a2 2 0 1 1 0-4h.09a1.7 1.7 0 0 0 .51-1 1.7 1.7 0 0 0-.34-1.88l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.7 1.7 0 0 0 9 4.6a1.7 1.7 0 0 0 1-.6V4a2 2 0 1 1 4 0v.09a1.7 1.7 0 0 0 1 .51 1.7 1.7 0 0 0 1.88-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.7 1.7 0 0 0 19.4 9c.14.32.34.61.6 1H20a2 2 0 1 1 0 4h-.09c-.26.39-.46.68-.51 1Z"/>',
 sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/>',
 moon:'<path d="M21 12.8A8.5 8.5 0 1 1 11.2 3 6.7 6.7 0 0 0 21 12.8Z"/>',
 fullscreen:'<path d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M8 21H5a2 2 0 0 1-2-2v-3M16 21h3a2 2 0 0 0 2-2v-3"/>',
 bell:'<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
 logout:'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
 info:'<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
 history:'<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 3v6h6"/><path d="M12 7v5l3 2"/>',
 reset:'<path d="M21 12a9 9 0 0 1-15.5 6.2"/><path d="M3 12A9 9 0 0 1 18.5 5.8"/><path d="M21 4v6h-6M3 20v-6h6"/>',
 chart:'<path d="M3 3v18h18"/><path d="m7 15 4-4 3 3 5-7"/>',
 plus:'<path d="M12 5v14M5 12h14"/>',
 edit:'<path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5Z"/>',
 trash:'<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v6M14 11v6"/>',
 eye:'<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
 temperature:'<path d="M14 14.8V5a2 2 0 1 0-4 0v9.8a4 4 0 1 0 4 0Z"/><path d="M12 9v7"/>',
 humidity:'<path d="M12 2s7 7.2 7 12a7 7 0 0 1-14 0c0-4.8 7-12 7-12Z"/>',
 ph:'<path d="m10 2 4 4-8 12a3 3 0 0 0 4 4l12-8-4-4"/><path d="M14 6l4 4"/>',
 gas:'<path d="M7 3h10v4H7z"/><rect x="6" y="7" width="12" height="14" rx="2"/><path d="M9 11h6M9 15h6"/>',
 electric:'<path d="M13 2 4 14h7l-1 8 10-13h-7l0-7Z"/>',
 battery:'<rect x="3" y="7" width="16" height="10" rx="2"/><path d="M21 11v2M7 11v2M11 11v2"/>',
 soil:'<path d="M12 21V10"/><path d="M12 10c-4 0-6-2.5-7-6 4 0 6.5 1.7 7 6Z"/><path d="M12 10c4 0 6-2.5 7-6-4 0-6.5 1.7-7 6Z"/>',
 light:'<path d="M9 18h6"/><path d="M10 22h4"/><path d="M8 14a6 6 0 1 1 8 0c-1 1-1 2-1 4H9c0-2 0-3-1-4Z"/>',
 distance:'<path d="M4 17h16"/><path d="M7 14l-3 3 3 3M17 14l3 3-3 3"/><path d="M8 7h8"/><path d="M8 4v6M16 4v6"/>',
 generic:'<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 0 1 5 0c0 2-2.5 2-2.5 4"/><path d="M12 17h.01"/>',
 home:'<path d="m3 10 9-7 9 7"/><path d="M5 10v10h14V10"/><path d="M9 20v-6h6v6"/>',
 building:'<path d="M4 21V5a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v16"/><path d="M9 21v-4h6v4M8 7h.01M12 7h.01M16 7h.01M8 11h.01M12 11h.01M16 11h.01"/>'
}; return `<svg ${common}>${paths[name]||paths.generic}</svg>`};
const iconKey=v=>{v=(v||'generic').toString().toLowerCase();if(v.includes('temp')||v.includes('dht'))return'temperature';if(v.includes('hum')||v.includes('nivel')||v.includes('agua'))return'humidity';if(v.includes('ph'))return'ph';if(v.includes('mq')||v.includes('gas'))return'gas';if(v.includes('ec')||v.includes('conduct'))return'electric';if(v.includes('bater'))return'battery';if(v.includes('suelo'))return'soil';if(v.includes('luz')||v.includes('ldr'))return'light';if(v.includes('dist'))return'distance';if(v.includes('casa'))return'home';if(v.includes('edificio'))return'building';if(v.includes('act')||v.includes('plug'))return'plug';return'generic'};
const setThemeIcon=()=>$('#themeIcon').innerHTML=svg(document.body.classList.contains('dark')?'sun':'moon');
function initData(){if(!state.sensors.length)state.sensors=[{id:1,type:'DHT22 (Temp+Hum)',name:'DHT22',port:'GPIO 4',variable:'dht22',icon:'temperature',values:['Temp: — °C','Hum: — %']},{id:2,type:'MQ135',name:'MQ135',port:'GPIO 34',variable:'mq135',icon:'gas',values:['CO₂: — ppm','Metano: — ppm','Butano: — ppm','Propano: — ppm']},{id:3,type:'pH',name:'pH',port:'GPIO 35',variable:'ph',icon:'ph',values:['—']},{id:4,type:'Conductividad (EC)',name:'EC',port:'GPIO 32',variable:'ec',icon:'electric',values:['— µS/cm']},{id:5,type:'Nivel',name:'Nivel H₂O',port:'GPIO 33',variable:'nivel',icon:'humidity',values:['— %']},{id:6,type:'Hum Suelo',name:'Hum. Suelo 1',port:'GPIO 27',variable:'soil1',icon:'soil',values:['—']}];if(!state.devices.length)state.devices=[{place:'Casa',name:'Casa',id:'ESP12345',serie:'EG123456',cat:'home',address:'San Miguel de Tucumán, Argentina',createdAt:'2025-07-28 02:30'}];if(!state.actuators.length)state.actuators=['Grupo Electrógeno','Lámpara','Ventilador','Válvula'].map((n,i)=>({id:i+1,name:n,on:false}));if(!state.plans.length)state.plans=[{name:'Plan Emprendedor',desc:'Solo un Dispositivo SalamandraIoT basado en ESP32',monthly:'$9,99 USD',annual:'$9,99 USD'},{name:'Plan Business',desc:'Hasta 5 Dispositivos SalamandraIoT basados en ESP32',monthly:'$9,99 USD',annual:'$9,99 USD'}];save()}
function applyTheme(){document.body.classList.toggle('dark',state.theme==='dark');document.body.className=document.body.className.replace(/role-\w+/,'')+' role-'+state.role;$('#authLogo').src=state.theme==='dark'?state.settings.logoDark:state.settings.logoLight;$('#headerLogo').src=$('#authLogo').src;$('link[rel="icon"]').href=state.settings.favicon;setThemeIcon()}
function fillSelects(){const p=$('#placeSelect'),d=$('#deviceSelect');p.innerHTML=state.places.map(x=>`<option ${x===state.selectedPlace?'selected':''}>${x}</option>`).join('');const devs=state.devices.filter(x=>x.place===state.selectedPlace);d.innerHTML=devs.map(x=>`<option ${x.id===state.selectedDevice?'selected':''}>${x.id}</option>`).join('');$('#dashPlace').textContent=state.selectedPlace;$('#devPlace').innerHTML=state.places.map(x=>`<option>${x}</option>`).join('')}
function renderSensors(){const grid=$('.sensors');grid.querySelectorAll('.sensor-card').forEach(e=>e.remove());state.sensors.forEach(s=>{let c=document.createElement('div');c.className='card sensor-card';c.innerHTML=`<h3>${svg(iconKey(s.icon||s.type||s.name))}<span>${safeHtml(s.name)}</span><button class="sensor-chart-btn" title="Ver historial gráfico" onclick="openSensorHistory(${s.id})">${svg('chart','svg-icon mini')}</button></h3>${(s.values||['—']).map(v=>`<p>${safeHtml(v)}</p>`).join('')}<div class="card-actions"><button class="icon-btn" title="Editar" onclick="editSensor(${s.id})">${svg('edit')}</button><button class="icon-btn" title="Eliminar" onclick="delSensor(${s.id})">${svg('trash')}</button></div>`;grid.appendChild(c)})}
function renderActuators(){$('#actuators').innerHTML=state.actuators.map(a=>`<div class="card"><b class="card-title">${svg('plug')}<span>${a.name}</span></b><div class="card-actions"><button class="icon-btn" title="Renombrar" onclick="renameActuator(${a.id})">${svg('edit')}</button><button class="icon-btn" title="Historial" onclick="Swal.fire('Historial de Actuador','Sin eventos registrados','info')">${svg('info')}</button><button class="switch ${a.on?'on':''}" onclick="toggleAct(${a.id})"><i></i></button></div></div>`).join('')}
function renderDevices(){let last=state.devices.at(-1);$('#lastDeviceInfo').textContent=last?`${last.createdAt} — ID: ${last.id}`:'—';$('#devicesGrid').innerHTML=state.devices.map(x=>`<div class="card device-card"><h3>${svg(iconKey(x.cat||x.name))}<span>${x.name}</span></h3><p><b>ID:</b> ${x.id}<br><b>Serie:</b> ${x.serie}</p><iframe class="device-map" loading="lazy" src="https://maps.google.com/maps?q=${encodeURIComponent(x.address)}&output=embed"></iframe><div class="card-actions"><button class="icon-btn" title="Información" onclick="Swal.fire('${x.name}','${x.address}<br>ID: ${x.id}','info')">${svg('info')}</button><button class="icon-btn" title="Editar" onclick="editDevice('${x.id}')">${svg('edit')}</button><button class="icon-btn" title="Eliminar" onclick="delDevice('${x.id}')">${svg('trash')}</button></div></div>`).join('')}
function renderPlans(){$('#plansGrid').innerHTML=state.plans.map((p,i)=>`<div class="card"><h3>${safeHtml(p.name)}</h3><p>${safeHtml(p.desc)}</p><p>Mensual: <b>${safeHtml(p.monthly)}</b><br>Anual: <b>${safeHtml(p.annual)}</b></p><div class="card-actions"><button class="icon-btn" title="Ver" onclick="Swal.fire({title:safeHtml(state.plans[${i}].name),html:safeHtml(state.plans[${i}].desc),icon:'info'})">${svg('eye')}</button><button class="icon-btn" title="Editar" onclick="editPlan(${i})">${svg('edit')}</button><button class="icon-btn" title="Eliminar" onclick="deletePlan(${i})">${svg('trash')}</button></div></div>`).join('')}
function renderUsers(){let roles=['SuperAdmin','Administradores','Emprendedor','Business'];$('#usersGrid').innerHTML=roles.map(r=>`<div class="card"><h3>${r}</h3><p>Gestión de usuarios del rol ${r}.</p></div>`).join('');$('#rolesGrid').innerHTML=roles.map(r=>`<div class="card"><h3>${r}</h3><label><input type="checkbox" checked> Ver</label><label><input type="checkbox" checked> Editar</label><label><input type="checkbox"> Eliminar</label></div>`).join('')}
function renderAll(){fillSelects();renderSensors();renderActuators();renderDevices();renderPlans();renderUsers();$('#lastReset').textContent=state.lastReset||'2025-07-19 19:10';$('#notifPanel').innerHTML='<b>Notificaciones</b><p>Instalación PWA disponible.</p><p>ESP32 listo para configurar.</p><p>Sin alarmas críticas.</p>';$('#avatar').src=state.user?.avatar||'https://api.dicebear.com/8.x/bottts/svg?seed=Salamandra'}
function loginOK(user){state.user=user||{email:$('#loginEmail').value,name:'Usuario'};save();$('#auth').classList.add('hidden');$('#app').classList.remove('hidden');renderAll();setTimeout(()=>Swal.fire({title:'Instalá Salamandra',text:'Agregá esta PWA a tu dispositivo para acceder más rápido.',icon:'info',confirmButtonText:'Entendido'}),500)}
function setupForms(){['login','register','recover'].forEach(k=>$$(`[data-auth="${k}"]`).forEach(a=>a.onclick=()=>{$$('.auth-form').forEach(f=>f.classList.remove('active'));$(`#${k}Form`).classList.add('active')}));$('#loginForm').onsubmit=async e=>{e.preventDefault();try{if(!SUPABASE_URL.includes('REEMPLAZAR')){let {data,error}=await db.auth.signInWithPassword({email:loginEmail.value,password:loginPassword.value});if(error)throw error;loginOK(data.user)}else loginOK()}catch(err){Swal.fire('Error',err.message,'error')}};$('#registerForm').onsubmit=async e=>{e.preventDefault();try{if(!SUPABASE_URL.includes('REEMPLAZAR')){let {error}=await db.auth.signUp({email:regEmail.value,password:regPassword.value,options:{data:{name:regName.value}}});if(error)throw error}toast('Usuario registrado');loginOK({email:regEmail.value,name:regName.value})}catch(err){Swal.fire('Error',err.message,'error')}};$('#recoverForm').onsubmit=async e=>{e.preventDefault();try{if(!SUPABASE_URL.includes('REEMPLAZAR'))await db.auth.resetPasswordForEmail(recoverEmail.value,{redirectTo:location.href});Swal.fire('Listo','Revisá tu correo','success')}catch(err){Swal.fire('Error',err.message,'error')}}}
function setupUi(){if('serviceWorker'in navigator)navigator.serviceWorker.register('./sw.js');$$('[data-icon]').forEach(el=>el.insertAdjacentHTML('afterbegin',svg(el.dataset.icon)));$('#headerLogo').onclick=()=>$('#sidebar').classList.toggle('open');$('#themeBtn').onclick=()=>{state.theme=state.theme==='dark'?'light':'dark';save();applyTheme()};$('#fullscreenBtn').onclick=()=>document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen();$('#logoutBtn').onclick=async()=>{if(await confirmAction({title:'Cerrar sesión',text:'¿Deseás salir de Salamandra IoT?',confirmButtonText:'Salir'})){state.user=null;save();location.reload()}};$('#avatar').onclick=async()=>{let {value}=await Swal.fire({title:'URL de imagen de perfil',input:'url',inputValue:state.user?.avatar||'',showCancelButton:true,confirmButtonText:'Guardar',cancelButtonText:'Cancelar'});if(value){state.user.avatar=value;save();renderAll();toast('Imagen actualizada')}};$$('.nav').forEach(b=>b.onclick=()=>{$$('.nav,.view').forEach(x=>x.classList.remove('active'));b.classList.add('active');$('#'+b.dataset.view).classList.add('active');if(innerWidth<760)$('#sidebar').classList.remove('open')});$('#placeSelect').onchange=e=>{state.selectedPlace=e.target.value;state.selectedDevice=(state.devices.find(d=>d.place===state.selectedPlace)||{}).id;save();renderAll()};$('#deviceSelect').onchange=e=>{state.selectedDevice=e.target.value;save()};$('#infoBtn').onclick=()=>Swal.fire('Dispositivo seleccionado',state.selectedDevice||'Sin dispositivo','info');$('#restartHistoryBtn').onclick=()=>Swal.fire('Historial de reinicios',state.lastReset||'Sin registros','info');$('#remoteResetBtn').onclick=async()=>{if(await confirmAction({title:'Reset remoto',text:`¿Enviar comando de reinicio al dispositivo ${state.selectedDevice||'seleccionado'}?`,icon:'warning',confirmButtonText:'Enviar reset'})){state.lastReset=new Date().toLocaleString('es-AR');save();renderAll();toast('Reset remoto enviado')}};$('#cpuChartBtn').onclick=()=>openCpuHistory();$('#addSensor').onclick=()=>openSensor();$('#addDevice').onclick=()=>openDevice();$('#createPlan').onclick=()=>editPlan(-1);$('#saveSettings').onclick=async()=>{if(await confirmAction({title:'Guardar configuración',text:'Se actualizarán logo, favicon e icono de instalación.',confirmButtonText:'Guardar'})){state.settings={logoLight:logoLight.value||defaultCfg.logoLight,logoDark:logoDark.value||defaultCfg.logoDark,favicon:faviconUrl.value||defaultCfg.favicon,installIcon:installIcon.value||defaultCfg.installIcon};save();applyTheme();toast('Configuración guardada')}};$('#saveMqtt').onclick=async()=>{if(await confirmAction({title:'Guardar Broker MQTT',text:'¿Confirmás actualizar los datos del broker?',confirmButtonText:'Guardar'}))toast('Broker MQTT guardado')};$('#saveProfile').onclick=async()=>{if(await confirmAction({title:'Guardar perfil',text:'¿Confirmás los cambios de perfil?',confirmButtonText:'Guardar'})){state.user.name=profileName.value;state.user.avatar=profileAvatar.value;save();renderAll();toast('Perfil guardado')}};}
const sensorTypes=['DHT11','DHT22 (Temp+Hum)','MQ135','Hum Suelo','pH','Conductividad (EC)','Nivel','Agregar otro'];const gpios=[0,2,4,5,12,13,14,15,16,17,18,19,21,22,23,25,26,27,32,33,34,35,36,39].map(x=>'GPIO '+x);const icons=[['generic','Genérico'],['temperature','Temperatura'],['humidity','Humedad / Nivel'],['ph','pH'],['gas','Gases'],['electric','Eléctrico / EC'],['battery','Batería'],['soil','Suelo'],['light','Luz'],['distance','Distancia'],['plug','Actuador']];
function fillModalOptions(){sensorType.innerHTML=sensorTypes.map(x=>`<option>${x}</option>`).join('');sensorPort.innerHTML=gpios.map(x=>`<option>${x}</option>`).join('');sensorIcon.innerHTML=icons.map(([v,n])=>`<option value="${v}">${n}</option>`).join('');devCat.innerHTML=[['home','Casa'],['building','Edificio'],['generic','Genérico'],['custom','Agregar otra']].map(([v,n])=>`<option value="${v}">${n}</option>`).join('')}
let editId=null;function openSensor(s=null){editId=s?.id||null;fillModalOptions();sensorTitle.textContent=s?'Editar Sensor':'Añadir Sensor';sensorName.value=s?.name||'';sensorVar.value=s?.variable||'';sensorIcon.value=iconKey(s?.icon||s?.type||s?.name);sensorDialog.showModal()}window.editSensor=id=>openSensor(state.sensors.find(s=>s.id===id));sensorForm.onsubmit=async e=>{e.preventDefault();if(sensorType.value.includes('Agregar'))return Swal.fire('Nuevo tipo','Podés sumarlo al catálogo o cargarlo desde Supabase.','info');let obj={id:editId||Date.now(),type:sensorType.value,name:sensorName.value,port:sensorPort.value,variable:sensorVar.value,icon:sensorIcon.value,values:['—']}; if(!(await confirmAction({title:editId?'Actualizar sensor':'Crear sensor',text:`¿Confirmás guardar ${obj.name}?`,confirmButtonText:'Guardar'})))return; editId?Object.assign(state.sensors.find(s=>s.id===editId),obj):state.sensors.push(obj);save();renderSensors();sensorDialog.close();toast('Sensor guardado')};window.delSensor=async id=>{let s=state.sensors.find(x=>x.id===id);if(await confirmAction({title:'Eliminar sensor',text:`¿Deseás eliminar ${s?.name||'este sensor'}?`,icon:'warning',confirmButtonText:'Eliminar'})){state.sensors=state.sensors.filter(s=>s.id!==id);save();renderSensors();toast('Sensor eliminado')}};
function openDevice(d=null){fillModalOptions();devName.value=d?.name||'';devId.value=d?.id||'ESP'+Math.floor(1000+Math.random()*8999);devSerie.value=d?.serie||'EG'+Math.random().toString(16).slice(-6).toUpperCase();devAddress.value=d?.address||'';devCat.value=iconKey(d?.cat||d?.name);deviceDialog.showModal()}deviceForm.onsubmit=async e=>{e.preventDefault();let obj={place:devPlace.value,name:devName.value,id:devId.value,serie:devSerie.value,cat:devCat.value,address:devAddress.value,createdAt:new Date().toLocaleString('es-AR')}; if(!(await confirmAction({title:'Guardar dispositivo',text:`¿Confirmás guardar ${obj.name} (${obj.id})?`,confirmButtonText:'Guardar'})))return; let i=state.devices.findIndex(d=>d.id===obj.id);i>=0?state.devices[i]=obj:state.devices.push(obj);state.selectedDevice=obj.id;save();renderAll();deviceDialog.close();toast('Dispositivo guardado')};window.editDevice=id=>openDevice(state.devices.find(d=>d.id===id));window.delDevice=async id=>{let d=state.devices.find(x=>x.id===id);if(await confirmAction({title:'Eliminar dispositivo',text:`¿Deseás eliminar ${d?.name||id}?`,icon:'warning',confirmButtonText:'Eliminar'})){state.devices=state.devices.filter(d=>d.id!==id);save();renderAll();toast('Dispositivo eliminado')}};
window.toggleAct=async id=>{let a=state.actuators.find(x=>x.id===id);let next=!a.on;if(await confirmAction({title:next?'Encender actuador':'Apagar actuador',text:`¿Confirmás cambiar el estado de ${a.name} a ${next?'ENCENDIDO':'APAGADO'}?`,icon:'question',confirmButtonText:next?'Encender':'Apagar'})){a.on=next;save();renderActuators();toast(`${a.name}: ${next?'encendido':'apagado'}`)}};window.renameActuator=async id=>{let a=state.actuators.find(x=>x.id===id);let {value}=await Swal.fire({title:'Nuevo nombre',input:'text',inputValue:a.name,showCancelButton:true,confirmButtonText:'Guardar',cancelButtonText:'Cancelar'});if(value&&value!==a.name){if(await confirmAction({title:'Confirmar cambio',text:`Renombrar ${a.name} como ${value}`,confirmButtonText:'Actualizar'})){a.name=value;save();renderActuators();toast('Actuador actualizado')}}};window.deletePlan=async i=>{let p=state.plans[i];if(await confirmAction({title:'Eliminar plan',text:`¿Deseás eliminar ${p?.name||'este plan'}?`,icon:'warning',confirmButtonText:'Eliminar'})){state.plans.splice(i,1);save();renderPlans();toast('Plan eliminado')}};window.editPlan=async i=>{let current=state.plans[i]||{name:'Nuevo Plan',desc:'Descripción',monthly:'$9,99 USD',annual:'$9,99 USD'};let {value:form}=await Swal.fire({title:i<0?'Crear Plan':'Editar Plan',html:`<input id="pn" class="swal2-input" value="${safeHtml(current.name)}"><input id="pd" class="swal2-input" value="${safeHtml(current.desc)}"><input id="pm" class="swal2-input" value="${safeHtml(current.monthly)}"><input id="pa" class="swal2-input" value="${safeHtml(current.annual)}">`,showCancelButton:true,confirmButtonText:'Guardar',cancelButtonText:'Cancelar',preConfirm:()=>({name:pn.value,desc:pd.value,monthly:pm.value,annual:pa.value})});if(form&&await confirmAction({title:i<0?'Crear plan':'Guardar cambios',text:'¿Confirmás la actualización del plan?',confirmButtonText:'Confirmar'})){i<0?state.plans.push(form):state.plans[i]=form;save();renderPlans();toast('Plan guardado')}};
let activeChart=null, activeChartContext=null;
const pad=n=>String(n).padStart(2,'0');
const toLocalInput=d=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
const fromLocalInput=v=>v?new Date(v):new Date();
function sensorUnit(s){let k=iconKey(s?.icon||s?.type||s?.name); if(k==='temperature')return '°C'; if(k==='humidity'||k==='soil')return '%'; if(k==='ph')return 'pH'; if(k==='gas')return 'ppm'; if(k==='electric')return 'µS/cm'; if(k==='light')return 'lx'; return 'valor'}
function simulatedHistory(sensor, from, to){
  const live = typeof telemetryRows === 'function' ? telemetryRows(sensor, from, to) : [];
  if(live.length) return live;
  const points=48, out=[]; const start=from.getTime(), end=to.getTime(), step=Math.max(1,(end-start)/(points-1));
  for(let i=0;i<points;i++){
    const d=new Date(start+step*i);
    out.push({date:d,label:d.toLocaleString('es-AR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'}),value:simValue(sensor, sensorMetricKey(sensor), d.getTime())});
  }
  return out;
}
function drawHistoryChart(sensor, from, to){
  const rows=simulatedHistory(sensor,from,to), ctx=$('#cpuChart');
  if(activeChart) activeChart.destroy();
  activeChart=new Chart(ctx,{type:'line',data:{labels:rows.map(r=>r.label),datasets:[{label:`${sensor.name} (${sensorUnit(sensor)})`,data:rows.map(r=>r.value),tension:.35,fill:false,pointRadius:3}]},options:{responsive:true,maintainAspectRatio:false,interaction:{mode:'index',intersect:false},plugins:{legend:{display:true},tooltip:{callbacks:{title:items=>rows[items[0].dataIndex].date.toLocaleString('es-AR')}}},scales:{x:{ticks:{maxRotation:45,minRotation:0}},y:{beginAtZero:false}}}});
}
function openHistoryModal(sensor){
  const now=new Date(), from=new Date(now.getTime()-24*60*60*1000);
  chartTitle.textContent=`Historial de ${sensor.name}`;
  chartHelp.textContent='Historial con fecha y hora. Datos simulados y actualizados en tiempo real hasta conectar lecturas reales desde ESP32/Supabase.';
  chartFrom.value=toLocalInput(from); chartTo.value=toLocalInput(now);
  activeChartContext=sensor;
  chartDialog.showModal();
  setTimeout(()=>drawHistoryChart(sensor,fromLocalInput(chartFrom.value),fromLocalInput(chartTo.value)),80);
}
window.openSensorHistory=id=>{const sensor=state.sensors.find(s=>s.id===id); if(sensor) openHistoryModal(sensor)};
function openCpuHistory(){openHistoryModal({id:999,name:'Temperatura CPU ESP32',type:'temperature',icon:'temperature'})}
function drawChart(){openCpuHistory()}
window.closeChartDialog=()=>{if(activeChart){activeChart.destroy();activeChart=null} chartDialog.close()};
$('#refreshChartBtn')?.addEventListener('click',()=>{if(!activeChartContext)return; const from=fromLocalInput(chartFrom.value), to=fromLocalInput(chartTo.value); if(from>=to)return Swal.fire('Rango inválido','La fecha desde debe ser anterior a la fecha hasta.','warning'); drawHistoryChart(activeChartContext,from,to)});

/* ===== Simulador en tiempo real hasta conectar ESP32/Supabase ===== */
state.telemetry = state.telemetry || {};
const RT_INTERVAL_MS = 3000;
let rtTimer = null;
function sensorMetricKey(sensor){
  const k=iconKey(sensor?.icon||sensor?.type||sensor?.name);
  if(k==='temperature') return sensor?.type?.toLowerCase().includes('hum') ? 'dht' : 'temperature';
  if(k==='humidity') return 'humidity';
  if(k==='soil') return 'soil';
  if(k==='ph') return 'ph';
  if(k==='gas') return 'gas';
  if(k==='electric') return 'ec';
  if(k==='light') return 'light';
  return 'generic';
}
function simValue(sensor, metric='main', t=Date.now()){
  const id=Number(sensor?.id||1), key=sensorMetricKey(sensor), phase=(t/1000/12)+(id*1.73)+(metric.length*.41);
  const wave=Math.sin(phase)*0.65+Math.cos(phase/2.7)*0.35;
  const jitter=((Math.floor(t/1000)+id*17+metric.length*11)%9-4)/10;
  let base=50, amp=8, dec=1;
  if(key==='dht' && metric==='temp'){base=24;amp=3.8;dec=1}
  else if(key==='dht' && metric==='hum'){base=58;amp=15;dec=0}
  else if(key==='temperature'){base=42;amp=8;dec=1}
  else if(key==='humidity'){base=63;amp=18;dec=0}
  else if(key==='soil'){base=47;amp=16;dec=0}
  else if(key==='ph'){base=6.85;amp=.55;dec=2}
  else if(key==='gas'){base=metric==='co2'?430:metric==='metano'?18:metric==='butano'?8:5;amp=metric==='co2'?75:8;dec=metric==='co2'?0:1}
  else if(key==='ec'){base=980;amp=210;dec=0}
  else if(key==='light'){base=540;amp=310;dec=0}
  const v=base+(wave*amp)+jitter;
  return Number(Math.max(0,v).toFixed(dec));
}
function formatSensorLive(sensor){
  const key=sensorMetricKey(sensor), now=Date.now();
  if(key==='dht') return [`Temp: ${simValue(sensor,'temp',now)} °C`,`Hum: ${simValue(sensor,'hum',now)} %`];
  if(key==='gas') return [`CO₂: ${simValue(sensor,'co2',now)} ppm`,`Metano: ${simValue(sensor,'metano',now)} ppm`,`Butano: ${simValue(sensor,'butano',now)} ppm`,`Propano: ${simValue(sensor,'propano',now)} ppm`];
  if(key==='ph') return [`${simValue(sensor,'ph',now)} pH`];
  if(key==='ec') return [`${simValue(sensor,'ec',now)} µS/cm`];
  if(key==='humidity'||key==='soil') return [`${simValue(sensor,key,now)} %`];
  if(key==='light') return [`${simValue(sensor,'light',now)} lx`];
  return [`${simValue(sensor,'main',now)}`];
}
function pushTelemetry(sensor){
  const key=String(sensor.id), now=new Date(), metric=sensorMetricKey(sensor);
  state.telemetry[key]=state.telemetry[key]||[];
  const value = metric==='dht' ? simValue(sensor,'temp',now.getTime()) : simValue(sensor,metric,now.getTime());
  state.telemetry[key].push({ts:now.toISOString(),value});
  state.telemetry[key]=state.telemetry[key].slice(-240);
}
function updateRealtimeSensors(){
  state.sensors.forEach(s=>{ s.values=formatSensorLive(s); pushTelemetry(s); });
  renderSensors();
  updateActiveRealtimeChart();
}
function telemetryRows(sensor, from, to){
  const rows=(state.telemetry[String(sensor.id)]||[])
    .map(r=>({date:new Date(r.ts), value:r.value}))
    .filter(r=>r.date>=from && r.date<=to);
  return rows.map(r=>({date:r.date,label:r.date.toLocaleString('es-AR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit'}),value:r.value}));
}
function startRealtimeSimulator(){
  if(rtTimer) clearInterval(rtTimer);
  updateRealtimeSensors();
  rtTimer=setInterval(updateRealtimeSensors,RT_INTERVAL_MS);
}
function updateActiveRealtimeChart(){
  if(!activeChart || !activeChartContext || !chartDialog.open) return;
  const sensor=activeChartContext, from=fromLocalInput(chartFrom.value), to=new Date();
  if(to>fromLocalInput(chartTo.value)) chartTo.value=toLocalInput(to);
  const rows=telemetryRows(sensor,from,to);
  if(!rows.length) return;
  activeChart.data.labels=rows.map(r=>r.label);
  activeChart.data.datasets[0].data=rows.map(r=>r.value);
  activeChart.options.plugins.tooltip.callbacks.title=items=>rows[items[0].dataIndex].date.toLocaleString('es-AR');
  activeChart.update('none');
}
function boot(){initData();setupForms();setupUi();applyTheme();renderAll();logoLight.value=state.settings.logoLight;logoDark.value=state.settings.logoDark;faviconUrl.value=state.settings.favicon;installIcon.value=state.settings.installIcon;startRealtimeSimulator();if(state.user)loginOK(state.user)}boot();

